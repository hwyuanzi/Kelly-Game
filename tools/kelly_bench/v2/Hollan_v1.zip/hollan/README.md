# Hollan — Kelly Game submission

**Name:** Hollan  
**Language:** C++17  
**Dependencies:** C++17 compiler and Python 3.8+ for `build.py`; standard libraries only.

## Submit

Send `Hollan_cpp17.zip` (or this entire `hollan/` folder), with the name **Hollan** and language **C++17**. The ZIP contains `hollan/bot.cpp`, `hollan/build.py`, and this README. It deliberately contains source rather than a platform-specific executable.

The organizer should extract the folder as `bots/hollan/` in the official repository and add this entry to `bots.json`:

```json
{"name":"Hollan","cwd":"bots/hollan","command":["./bot"],"build":["{python}","build.py"]}
```

From the official repository root:

```sh
python3 bots/hollan/build.py
python3 start.py match Hollan "Kelly (C++)" --config params/competition_2000.txt --no-browser
```

The referee builds automatically before a match, so the explicit build is optional. Rebuild on the competition machine; a macOS executable is not a Linux executable. `build.py` is the unchanged official build script: it supports `CXX`, c++, g++, clang++, and the Visual Studio compiler. No setup beyond the official prerequisites is needed. Windows uses `bot.exe` automatically.

## Strategy

Hollan maximizes **expected final capital**, the competition's additive score, with a finite-horizon Bellman dynamic program. Capital is conserved, so only our share of the total and the round are needed to describe the financial state. Every known future probability is used. Both possible outcomes are evaluated explicitly, including the sum-of-bets transfer, limited liability, integer rounding, bankruptcy, and the 20% limit.

The opponent's previous bet is reconstructed from the change in our capital minus our previous bet. Ten public-state models span ordinary Kelly; quarter, half, three-quarter, 1.5x and 2x Kelly; favorable-round maximum bets; always-maximum bets; passive play; and opponent-aware Kelly. Discounted prediction errors select a model with hysteresis and one-dollar rounding tolerance. Tables are computed lazily and cached.

The planner uses an approximately 800-point interior capital grid, exact one-dollar states within $64 of either bankruptcy boundary, 25 coarse action candidates plus the pot-clipping kink, and a finer live integer search. Opponent-aware Kelly supplies another live candidate and the bounded-time fallback. The final objective is terminal money rather than log wealth; the resulting strategy can rationally take risk on an unfavorable round to reach better future opportunities.

Binary outcome expectations are evaluated directly instead of sampled during play. Monte Carlo is used for empirical selection and validation, where it provides evidence about actual scores without adding noisy runtime decisions.

## Validation and performance

The final held-out evaluation used 19 configurations (three supplied and 16 new randomized sequences), 3,000 random draw pairs per configuration, and both A/B roles: **57,000 pairings per opponent**, or **798,000 Hollan games** across seven opponents.

| Opponent | Hollan's mean share of pairing money | Improvement over official Kelly against that opponent |
|---|---:|---:|
| Official Kelly | 56.99% | +7.06 percentage points |
| Conservative half-Kelly | 59.51% | +6.22 points |
| Aggressive favorable-round maximum | 56.40% | +6.90 points |
| Adaptive opponent-aware Kelly | 55.15% | +6.20 points |
| Always maximum | 63.21% | +6.15 points |
| Passive | 80.21% | +1.84 points |
| Double Kelly | 56.10% | +7.04 points |

The gain against official Kelly has a paired approximate 95% interval of **+6.89 to +7.23 percentage points** on this test suite. These are Monte Carlo estimates, not a guarantee against unknown competition bots.

All 19 official tests passed. Independent exhaustive Bellman checks covered 170,380 small states under AddressSanitizer and UndefinedBehaviorSanitizer. Sixty additional official-referee games covered tiny capitals, extreme probabilities, frozen games, 2,000 rounds, and the oversized-horizon fallback: no illegal or adjusted bets, crashes, or timeouts. Official `start.py` matches and a 15-pairing tournament also completed without forfeits. Observed cumulative thinking time was below 0.5 seconds per Hollan game on the development machine; slower hosts have guarded table construction and a fallback after 65 seconds of internal computation.

Only the permitted strategy section of the official C++ template was changed. The communication protocol, official referee, sample bots, and original template remain unchanged.
